
fe <- function(
  x = 2, n0 = 50, invis = TRUE, oneSided = TRUE
  )
{
  d <- getDdata(x,n0)
  rownames(d) <- c("r","n")
  d <- t(d)
  # data in contingency table form as required for fisher.test()
  dc <- cbind(d[,1],d[,2]-d[,1])
  rownames(dc) <- rownames(d)
  colnames(dc) <- c("r","n - r")
  cat("data as r / n\n");print(d)
  cat("\ndata as contingency table (as for e.g. SigmaPlot)\n");print(dc)
  cat("\nTest reported is 1-sided, H(A) is response probability higher in treated group.\n")
  p <- c(
    p.2sided = fisher.test(dc,alternative="two.sided")$p.value,
    p.1sided = fisher.test(dc,alternative="less")$p.value
    )
  cat("\n\np = ",signif(p[[1]],2)," (1-sided)\n")
  if(invis) invisible() else return(p)
}
