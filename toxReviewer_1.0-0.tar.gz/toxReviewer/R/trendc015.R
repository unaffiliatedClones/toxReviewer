
trendc015 <- function(x, n0, sdse = "se") {
  if(is(x,"data_c")) d <- x else d <- data_c(x = x, n0 = n0, sdse = sdse)
  ccoef <- 1:nrow(d)
  ccoef <- ccoef - mean(ccoef) 
  dum <- co(
    x, n0, sdse = "se", ccoef = ccoef, do.plot = TRUE, 
    verbose=TRUE, invis = TRUE
    )
}
# trendc015("1-1;2-1;3-1", n0=5)

