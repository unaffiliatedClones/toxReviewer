
co <- function(
  x, n0, sdse = "se", ccoef = NULL, 
  do.plot = TRUE, verbose=TRUE, invis = TRUE)
  {
### general continuous-response code ###
  if(is(x,"data_c")) d <- x else d <- data_c(x = x, n0 = n0, sdse = sdse)
  rm(x)
  summary_c(d, do.plot) 
  dfR  <- attr(d,"dfR")
  msw <- attr(d,"MSW") # MS within group  
  results <- list(data=d)
  m.anova <- attr(d,"m.anova")
  if(is.null(ccoef)) ccoef <- 1:nrow(d)
  ccoef <- ccoef - mean(ccoef)         # center
  cest  <- sum(ccoef*d$m)              # estimate contrast
  var.cest <- msw * sum(ccoef^2 /d$n)  # variance of estimated contrast 
  t.contr <- cest / sqrt(var.cest)      
  Fstat <- t.contr^2
  p <- pf(Fstat, 1, dfR, lower.tail=FALSE)
  if(verbose) cat("\ncontrast coefficients = ", ccoef, 
                  "\ntrend p = ", signif(p,4))
  results$p.values <- p

### general code for continuous response 
  if(invis) invisible() else return(results)
###
  }
# d <- co("1-1;2-1;3-1", n0=5, invis=F, do.plot=F)
