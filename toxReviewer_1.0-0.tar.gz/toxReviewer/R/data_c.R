data_c <- function(x = 3, n0 = NULL, sdse = "se", dose=NULL) {
  if(is(x,"data_c")) {  
    return(x)
  } else {  
    if(is.matrix(x)|is.data.frame(x)) {
      y <- data.frame(x)
      cnams <- colnames(y)
      if(!("m" %in% cnams)) stop("\n! (data_c) 'm' missing")
      if(!("n" %in% cnams)) stop("\n! (data_c) 'n' missing")
      if(!(any(cnams %in% c("sd","se")))) stop(
        "\n! (data_c) input includes nether std.dev. nor std.err."
        )
      rm(x)
    } else if((is.numeric(x) & length(x)==1)) { 
      ## x interpreted as number groups for console data entry
      ## n0 required.
      num.gr <- x
      if(!(sdse %in% c("sd","se"))) stop("\n! (data_c) expected one of 'sd','se'")
      if(!(is.numeric(n0) && n0>0)) stop("\n! 'n0' not a valid group N")
      # interpret input as num.groups, get 2*x data from console
      if(length(n0)==1) n0 <- rep(n0, num.gr)
      d0 <- rbind(rep(0,num.gr),rep(0,num.gr),n0)
      rownames(d0) <- c("mean", sdse, "n")
      if(num.gr==2) {
        cn <- c("Control","Treated")
      } else {
        cn <- c("Control", paste("Dose ", 1:(num.gr-1)))
        cn[2] <- paste(cn[2], "(Low)") 
        cn[num.gr] <- paste(cn[num.gr], "(High)")
      }
      colnames(d0) <- cn
      d0 <- edit(d0)    
      rownames(d0) <- c("m", sdse, "n")
      y <- data.frame(t(d0))
      rm(x, d0)
    } else if(is.character(x)) {  ## case:  x is semicolon-delimited string
      if(!(sdse %in% c("sd","se"))) stop("\n! (data_c) sdse not one of 'sd','se'")
      d0 <- rbind(strData(x,"-"),n0)
      rownames(d0) <- c("m",sdse,"n")
      y <- data.frame(t(d0))
      rm(x, d0)
    } else stop("\n! (data_c) bad input")
    cnams <- colnames(y)
    if(!("se" %in% cnams)) y <- transform(y, se = sd/sqrt(n))
    if(!("sd" %in% cnams)) y <- transform(y, sd = se*sqrt(n))
    if(!("dose" %in% colnames(y))) {
      if(is.null(dose)) dose <- 1:nrow(y)
      y$dose <- dose 
    }
    y <- y[c("dose","n","m","sd","se")]
    ### percent difference treated relative to control
    if(all(y$m >=0) & (y$m[1] > 0)) {
      y$perc.diff <- 100*(y$m - y$m[1])/y$m[1] 
      y$perc.diff[1] <- NA
      y <- y[c("dose","n","m","perc.diff","sd","se")]
    }
    attr(y,"dfR") <- with(y, sum(n-1))
    attr(y,"num.groups") <- nrow(y)
    attr(y,"MSW") <- with(y, sum((n-1)*sd^2)) / attr(y,"dfR")
    class(y) <- c("data_c","data.frame")
    d.fabr <- fabricate(y)
    attr(y,"m.anova") <- lm(response ~ group, data = d.fabr)
    attr(y,"pseudo.data") <- d.fabr
    return(y)
  }
} ################################################################
#data_c("1-1;1-1;1-1;4.49-1",9)
# st("1-1;1-1;1-1;4.49-1",9)
# data_c("1-2;2-1",n=3)

