
ca <- function(x = 3, n0 = 50, invis = TRUE, oneSided = TRUE, cc = FALSE, nsim=0 )
{
  if(!is.logical(cc)) stop(
    "Correction for continuity must be specified as TRUE/FALSE"
    )
  d <- getDdata(x,n0)
  rownames(d) <- c("r","n")
  if(invis) print(d)
  if(nrow(d) != 2 | ncol(d) < 2) stop(
   "\n! data matrix for dichotomous response must be 2*k, K>=2"
   )
  O <- d[1,] # notation follows Haseman
  N <- d[2,]
  if(any( O>N )) stop("num.observed > num.on test for some group")
  if(any( O<0 )) stop("num.observed is <0 for some group")
  if(any( N<=0)) stop("num.on test is 0 or lower for some group")
  R <- sum(O)
  M <- sum(N)
  if(R %in% c(0,M)) {
    cat("\nNote : responses are 0% or 100% in all treatment groups -")  
    cat("missing values returned for p-values")  
    p.1sided <- p.2sided <- NA
  } else {
    ### summaries
    k <- ncol(d)
    E <- N*R/M
    D <- 0:(k-1)
    V <- (M-R)*R*(M*sum(N*D^2)-(sum(N*D)^2))/M^3
    if(V<=0) stop("\n ! code is wrong - 'variance' not positive\n")
    ### asymptotic test 
    if(invis) cat("\nTest computations use equally-spaced dose scores 0,1,...")
    Zn <- sum(D*(O-E))
    if(cc & (Zn != 0)) {
      Z <- (Zn + ifelse( Zn < 0, 0.5, -0.5 ))/sqrt(V) 
    } else {
      Z <- Zn / sqrt(V)
    }
    p.1sided <- pnorm( Z, lower.tail = FALSE )
    p.2sided <- 2*min( p.1sided, 1 - p.1sided )
    
    if(invis) {
      cat(paste("\nCorrection for continuity",ifelse(cc,""," not")," requested",
       sep=""))
      p.report <- ifelse( oneSided, p.1sided, p.2sided )
      p.report <- ifelse( p.report <0.001, "<0.001", signif(p.report,3))
      cat("\n\np=",p.report);rm(p.report)
      if(oneSided) {
        cat(" from 1-sided test for response increasing with dose (asymptotic)\n")
      } else {
        cat(" from 2-sided test for response trending +/- with dose (asymptotic)\n")
      }
    }
    
    # Monte Carlo permutation test 
    if( nsim== 0 ) {
      if(invis) invisible() else return(
        c(p.2sided = p.2sided, p.1sided = p.1sided)
        )
    } else {  # compute Monte Carlo permutation p-values, console & value
      testStat.1S <- sum(D*O)   # value of test stat for data
      testStat.2S <- abs(Zn)
      indic <- c(rep(TRUE, R),rep(FALSE, M-R))
      nReg.1S <- nReg.2S <- 0L  # count in rejection regions
      for(i in 1:nsim) {
        rindic <- sample(indic)
        loc <- 1
        r.sim <- NULL  # simulated counts 
        for(j in 1:k) {
          r.sim <- c(r.sim, sum(rindic[loc:(loc+N[j]-1)]))
          loc <- loc + N[j]
        } # j : group indiex 
        nReg.1S <- nReg.1S + (sum(D*r.sim) > testStat.1S)
        nReg.2S <- nReg.2S + (abs(sum(D*(r.sim - E))) > testStat.2S)
      } # i : random permutations 
      p.1S.MC <- nReg.1S / nsim 
      p.2S.MC <- nReg.2S / nsim 
      p.report <- ifelse( oneSided, p.1S.MC, p.2S.MC )
      p.report <- ifelse( p.report <0.001, "<0.001", signif(p.report,3))
      cat("\n\np=",p.report);rm(p.report)
      if(oneSided) {
        cat(" from 1-sided test for response increasing with dose (Monte Carlo)\n")
      } else {
        cat(" from 2-sided test for response trending +/- with dose (Monte Carlo)\n")
      }
      if(invis) invisible() else return(
        c(p.2sided = p.2S.MC, p.1sided = p.1S.MC)
      )
    } # if nsim GT 0 [do Monte Carlo permutation test]
  }   # if[all-or-none responses]
  # note values (or invisible()) have been specified conditionally.
  if(ncol(d)==2) cat(
     "\nnote: Fisher's exact test, e.g., fe(), is customary for 2 groups.\n"
     )
}
#x <- ca(d.i,invis=F)
