
isoreg2 <- function(x, n0, updown = "ud", verbose=TRUE) 
  {
### general continuous-response code ###
  if(is(x,"data.frame") && any(names(x)=="m") && any(names(x)=="n")) {
    d <- x } else d <- data_c(x, n0)
  n <- d$n  # number per group 
  m <- d$m  # mean per group 
  rm(x,d)
####  
  ## reparam functions
  mu2theta <- function(x) c(x[1],diff(x))
  theta2mu <- function(x) cumsum(x)
  ## weighted SS objective function for mu and theta parametrizations 
  wss.mu    <- function(mu) sum(n*(m - mu)^2)
  wss.theta <- function(theta) sum(n*(m - theta2mu(theta))^2)
  if(updown == "u") {  # monotone non-decreasing 
    mu.iso0 <- isoreg(m)$yf  # initial feasible
    theta0  <- mu2theta(mu.iso0)
    soln <- solnp(
      pars = theta0, 
      fun  = wss.theta,
      ineqfun = function(x) x[-1],
      ineqLB  = rep(0, length(m)-1),
      ineqUB  = rep(diff(range(m)), length(m)-1)
      )
    if(soln$convergence) stop("\n! solnp() convergence failure in isoreg2()")
    mu  <- theta2mu(soln$par)
    wss <- wss.mu(mu)
  } else if(updown == "d") {  # monotone non-increasing
    mu <- (-1)*isoreg2(data.frame(n = n,m = -m), updown="u", verbose=FALSE)
    #mu.iso0 <- (-1)*modl$unweighted.isotone
  } else if(updown == "m") {  # best monotone non-de/increasing 
    mu.u <- isoreg2(data.frame(n = n, m = m), updown="u", verbose=FALSE)
    mu.d <- isoreg2(data.frame(n = n, m = m), updown="d", verbose=FALSE)
    wss.u <- wss.mu(mu.u)
    wss.d <- wss.mu(mu.d)
    if(wss.u < wss.d) mu <- mu.u else mu <- mu.d
  } else stop(paste("\n ! '", updown, "' not ok in input for isoreg2()" ))
  if(verbose) print(cbind(observed=m, N=n, fits=mu))
  return(mu)
  }
#isoreg2("1-1;3-1;2-1",n0=c(5,3,15), "m")

