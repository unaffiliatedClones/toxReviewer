
coPol <- function(
  x, n0, sdse = "se", ccoef = NULL, do.plot = TRUE, verbose=TRUE, invis = TRUE
  ) 
{
  ### common (continuous-response) ###
  if(is(x,"data_c")) d <- x else d <- data_c(x = x, n0 = n0, sdse = sdse)
  rm(x)
  if(verbose) summary_c(d, do.plot) 
  #### special ####
  d.raw  <- attr(d, "pseudo.data")  # observation-level (pseudo) data
  num.gr <- attr(d, "num.groups")
  dose.rank <- as.numeric(d.raw$group)
  model.lm  <- lm(response ~ poly(dose.rank, num.gr - 1), d.raw,
                  singular.ok = FALSE)
  results.t.eq <- coeftest(model.lm)     
  results.t.un <- coeftest(model.lm, vcov = hccm)
  rownames(results.t.eq)[2]<- "linear trend"
  rownames(results.t.un)[2]<- "linear trend"
  p.eq <- results.t.eq[2,4]
  p.un <- results.t.un[2,4]

  if(verbose) {
    cat("\nOrthogonal Polynomials Equal Variance\n")
    print(results.t.eq, digits=4)
    cat("\ntrend p = ", signif(p.eq,4))
    cat("\n\nUnequal Variance\n")
    print(results.t.un, digits=4)
    cat("\ntrend p = ", signif(p.un,4))
  }  
  if(!is.null(ccoef)) cat("\n! warning : user-supplied contrasts are not yet supported\n")
  results <- list(data=d) # summary data object 
  results$p.eq <- p.eq
  results$p.un <- p.eq
  if(invis) invisible() else return(results)
}

