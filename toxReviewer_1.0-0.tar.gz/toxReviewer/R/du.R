du <- function(x, n0, sdse = "se", do.plot = TRUE, verbose=TRUE, invis = TRUE) 
  {
  if(is(x,"data_c")) d <- x else d <- data_c(x = x, n0 = n0, sdse = sdse)
  rm(x)
  summary_c(d, do.plot) 
  modl <- attr(d, "m.anova")
  dose <- levels(as.factor(d$dose))
  ####  
  testResults <- glht(modl, linfct = mcp(group = "Dunnett"))
  if(verbose) {
    cat("\nresults of glht{multcomp}:")
    print(summary(testResults))
  }
  p.labels <- paste(dose[-1], "-vs-1", sep="")
  p.values <- as.vector(summary(testResults)$test$pvalues)
  names(p.values) <- p.labels
  ## summary stats with doses in columns, rows for stats 
  if(verbose) {
    dpr <- rbind(t(subset(d, select=-dose)),
                 p = c(NA, p.values) )
    colnames(dpr) <- paste("Group", d$dose)
    colnames(dpr)[1] <- "Control"
    print(dpr, na.print=".")
  } 
  if(invis) invisible() else {
    retval <- NULL
    retval$allResults <- testResults
    retval$p.values <- p.values 
    return(retval)
  }   
} 
#du("1-1;2-1;3-1",n0=5)
# dta <- data.frame(m=c(1,2,3),se=c(0.5,1,1.5),n=rep(25,3)) 
# du(dta)