summary_c <- function(x, do.plot = TRUE) 
  {
  if(!is(x, "data_c")) stop("\n\n! input not of class data_c\n")
  if(do.plot) pl(x)
  print(x)
  cat("\n")
  print(anova(attr(x,"m.anova")))
} 
# x <- data_c("1-1;2-1;3-1",n0=5)
# summary_c(x)
