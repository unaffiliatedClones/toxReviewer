
pl <- function(x, n0, scale= "c", var.equal = FALSE, sdse = "se", 
               xlab="treatment group", ylab="response") 
  {
  if(tolower(scale) != "c") stop("\n! (pl) not implemented for non-continuous response")
  if(is(x,"data_c")) d <- x else d <- data_c(x = x, n0 = n0, sdse = sdse)
  rm(x)
  k <- nrow(d)
  tcrit   <- qt(0.975, attr(d,"dfR"))
  if(var.equal) {
    sd.pool <- sqrt(attr(d,"MSE"))
    se <- sd.pool / sqrt(d$n)
  } else se <- d$se
  m <- d$m
  hafwit <- tcrit*se 
  errbar(
    1:k, y = m, 
    yplus = m + hafwit, 
    yminus= m - hafwit,
    xlab = xlab, ylab = ylab, 
    xlim = c(0.5, k + 0.5),
    col="darkblue",
    lab = c(k, 5, 7)
    )
  return(d)
}
#pl("1-1;2-1;3-1", 7)
