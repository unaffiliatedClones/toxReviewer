
getDdata <- function(x = 3, n0=50) {
  if((is.numeric(x) & length(x)==1)) { 
    # interpret input as num.groups, get data from console
    d0 <- rbind(rep(0,x),rep(n0,x))
    rownames(d0) <- c("num.responding","num.on test")
    # colnames() conditionally
    if(x==2) {
      cn <- c("Control","Treated")
    } else {
      cn <- c("Control", paste("Dose ", 1:(x-1)))
      cn[2] <- paste(cn[2], "(Low)") 
      cn[x] <- paste(cn[x], "(High)")
    }
    colnames(d0) <- cn
    d <- edit(d0)    
  } else if(is.character(x)) {
    d <- strData(x,"/")  # semicolon -delimited string
  } else d <- x  # interpret as 2*K data 
  return(d)
}
