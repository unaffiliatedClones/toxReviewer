
fabricate <- function(x = NULL, n=NULL, m=NULL, sd=NULL, dose=NULL) {
  ## generate 'raw data' from summary normal summary stats
  if(!is.null(x)) { ## then data in other arguments
    if(!is(x,"data_c")) stop("\n! (fabricate) 'x' is not NULL & not class 'data_c'")
    n <- x$n; m <- x$m; sd <- x$sd ## note dose could be 1,2,...,num.dose
    if(!is.null(dose) && any(colnames(x)=="dose")) dose <- x$dose
    k <- nrow(x)
    rm(x)
  } else {  ## ignore x
    rm(x)
    k <- length(m)
    if(k > 1 & (length(n)==1)) n <- rep(n,k)
    if(is.null(dose)) {
      if(k > 1) dose <- 1:k
    } else {
      if(length(dose) != k) stop("! (fabricate) 'dose' wrong length")
    }
  }
  if(any(n < 2)) stop("\n! (fabricate) group sizes < 2 not implemented.")
  if(k == 1) { ### one group ###
    numbelow <-  trunc(n/2) ## num{< mean} 
    if(n %% 2) {  ## odd  ##
      del <- sd 
      y <- c(rep(m-del, numbelow), m, rep(m+del, numbelow))
    } else {      ## even ##
      del <- sd *sqrt((n-1)/n)
      y <- c(rep(m-del, numbelow), rep(m+del, numbelow))
    }
  } else {     ### multiple groups - recursive ###
    if(is.null(dose)) dose <- 1:k
    y <- NULL
    for(i in 1:k) {
      y.i <- fabricate(n = n[i], m = m[i], sd = sd[i])
      y.i <- cbind(dose = rep(dose[i], n[i]), response = y.i)
      y   <- rbind(y, y.i)
    }
    y <- transform(y, group = as.factor(dose))
  }            ### if[1 group] else {..}
  return(y)
}
