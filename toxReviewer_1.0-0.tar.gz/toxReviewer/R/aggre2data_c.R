
# library(multcomp)
# library(toxReviewer)
aggr2data_c <- function(xnum, xfac)
{
  ret <- aggregate(
    xnum, list(xfac), 
    function(x) c(n = length(x), m = mean(x), sd = sd(x))
    )$x
  names(ret) <- c("group", "n", "m", "sd")
  ret <- data_c(ret)
  return(ret)
}
set.seed(1324)
set.seed(1234)
num.doses <- 6
nper <- 10
npervc <- rep(nper, num.doses)
mm <- data.frame(
  Dose = rep(0:(num.doses - 1), each = nper)
)
BUN.means <- c(14,17,17,15,20,14)
mm$BUN <- npervc + rnorm(num.doses*nper, 0, 3)
with(mm, plot(Dose, BUN))
mm$Dose <- as.factor(mm$Dose)

xnum <- mm$BUN
xfac <- mm$Dose

