
# library(multcomp)
# library(Hmisc)
# library(toxReviewer)
## ##

widu <- function(x, n0, sdse = "se") 
{
  ## fancy print p-values 
  ## arg1 class of x is "glht"
  p.prnt <- function(x, subset=NULL) {  
    pmtx <- data.frame(x$test[c("tstat","pvalues")])
    if(!is.null(subset)) pmtx <- pmtx[subset,]
    colnames(pmtx) <- c("t","p")
    printCoefmat(
      pmtx, digits=3, eps = 0.001,
      signif.legend=TRUE, has.Pvalue = TRUE, P.values = TRUE
      )
    invisible()
  }
  ### common code for continuous response ###
  if(is(x,"data_c")) d <- x else d <- data_c(x = x, n0 = n0, sdse = sdse)
  rm(x)
  summary_c(d, do.plot=FALSE) 
  d.raw  <- attr(d, "pseudo.data")  # observation-level (pseudo) data
  num.gr <- attr(d, "num.groups")
  m.aov  <- attr(d, "m.anova")

  #### special code ####
  
  ## contrast matrices for separate du and wi
  contr.du <- contrMat(d$n, type = "Dunnett")
  contr.wi <- contrMat(d$n, type = "Williams")

  ## Dunnett without adj for simultaneous Williams
  
  cat("\nDunnett - standard single-step - 2-sided\n\n")
  dustuff <- summary(
     glht(m.aov, linfct = mcp(group = contr.du), alternative = "two.sided")
     )
  p.prnt(dustuff)  # p-values in matrix 
   
  ## Williams without adj for simultaneous Dunnett
  
  cat("\nTrend Test, Williams-type based on contrasts - 2-sided\n")
  wistuff <- summary( 
    glht(m.aov, linfct = mcp(group = contr.wi), alternative = "two.sided")
    )
  p.wi <- min(wistuff$test$pvalues)
  cat("\np =", signif(min(p.wi),2))
  
  ## Williams adjusted for simultaneous Dunnett (and vice versa)

  contr.widu <- rbind(contr.du, contr.wi[-1,])
  widustuff <- summary(
    glht(m.aov,linfct = mcp(group = contr.widu), alternative = "two.sided")
    )
  # note that the du and wi sets have one contrast in common,
  # the last du contrast and the 1st wi contrast 
  # assign this to du for adjusted du (comparable to non-adjusted)
  # assign to wi for adjusted wi 
  du.locns <- 1:nrow(contr.du)                # Dunnett contrast (indices of)
  wi.locns <- nrow(contr.du):nrow(contr.widu) # Williams contrasts

  ## Dunnett adj for simultaneous Williams

  cat("\n\npairwise comparisons adjusted for simultaneous trend test\n\n")
  p.prnt(widustuff, du.locns)  # p-values in matrix 

  ## Williams  adj for simultaneous Dunnett

  cat("\n\ntrend test adjusted for simultaneous pairwise comparisons:  ")
  p.wi.adj <- min(widustuff$test$pvalues[wi.locns])
  cat("p =", signif(p.wi.adj,2))

  invisible()
}

