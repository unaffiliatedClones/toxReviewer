
strData <- function(x, sep="-") {
  x <- unlist(str_split(x, ";"))
  va <- NULL
  for(i in 1:length(x)) va <- cbind(
    va, 
    as.numeric(unlist(str_split(x[i],sep)))
    )
  va
  }


